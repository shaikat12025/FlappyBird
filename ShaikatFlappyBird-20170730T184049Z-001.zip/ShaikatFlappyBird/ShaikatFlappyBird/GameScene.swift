import SpriteKit


class GameScene: SKScene, SKPhysicsContactDelegate {
    // declare and instantiate all the variables you will need for this class. Place the following code right after the class declaration.
    
    var isGameStarted = Bool(false)
    var isDied = Bool(false)
    let CoinSound = SKAction.playSoundFileNamed("CoinSound.mp3", waitForCompletion: false)
    
    
    //need them to store the score, display score label, high score label, “tap to play” label, restart button, pause button, logo image, the pillars and the bird.
    
    var score = Int(0)
    var scoreLbl = SKLabelNode()
    var taptoplayLbl = SKLabelNode()
    var restartBtn = SKSpriteNode()
    var pauseBtn = SKSpriteNode()
    var logoImg = SKSpriteNode()
    var wallPair = SKNode()
    var moveAndRemove = SKAction()
    
    // create the bird atlas for animation
    let birdAtlas = SKTextureAtlas(named: "player")
    var birdSprites = Array<Any>()
    var bird = SKSpriteNode()
    var repeatActionBird = SKAction()
    
    
    
    
    
    
    
    
    
       override func didMove(to view: SKView) {
        createScene()
        
            }
    func didBegin(_ contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        if firstBody.categoryBitMask == CollisionBitMask.birdCategory && secondBody.categoryBitMask == CollisionBitMask.pillerCategory || firstBody.categoryBitMask == CollisionBitMask.pillerCategory && secondBody.categoryBitMask == CollisionBitMask.birdCategory || firstBody.categoryBitMask == CollisionBitMask.birdCategory && secondBody.categoryBitMask == CollisionBitMask.groundCategory || firstBody.categoryBitMask == CollisionBitMask.groundCategory && secondBody.categoryBitMask == CollisionBitMask.birdCategory{
            enumerateChildNodes(withName: "wallPair", using: ({
                (node, error) in
                node.speed = 0
                self.removeAllActions()
            }))
            if isDied == false{
                isDied = true
                createRestartBtn()
                pauseBtn.removeFromParent()
                self.bird.removeAllActions()
            }
        } else if firstBody.categoryBitMask == CollisionBitMask.birdCategory && secondBody.categoryBitMask == CollisionBitMask.flowerCategory {
            run(CoinSound)
            score += 1
            scoreLbl.text = "\(score)"
            secondBody.node?.removeFromParent()
        } else if firstBody.categoryBitMask == CollisionBitMask.flowerCategory && secondBody.categoryBitMask == CollisionBitMask.birdCategory {
            run(CoinSound)
            score += 1
            scoreLbl.text = "\(score)"
            firstBody.node?.removeFromParent()
        }
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isGameStarted == false{
            //1
            isGameStarted =  true
            bird.physicsBody?.affectedByGravity = true
            createPauseBtn()
            
            //1- touchesBegan is called whenever the user touches the screen. Here we set isGameStarted flag to true, set the bird to be affected by gravity and create the pause button.
            
            
            //2
            logoImg.run(SKAction.scale(to: 0.5, duration: 0.3), completion: {
                self.logoImg.removeFromParent()
            })
            
            taptoplayLbl.removeFromParent()
            
            
              //2- This will run an action on the logo which scales it to half its size in 0.3 seconds. When the animation is completed, the logo is removed from the scene.
            //3
            self.bird.run(repeatActionBird)
            
            //3- You run the repeatActionBird action that you created earlier on the bird which makes it flap its wings by requesting the images from player.atlas in a sequence. You don’t want to give it a velocity because it has to remain steady, so you set its velocity to zero. Then, you apply an upward impulse on the bird that makes it go up.
            
            //TODO: add pillars here
            
            //1
            let spawn = SKAction.run({
                () in
                self.wallPair = self.createWalls()
                self.addChild(self.wallPair)
            })
            //2
            let delay = SKAction.wait(forDuration: 1.5)
            let SpawnDelay = SKAction.sequence([spawn, delay])
            let spawnDelayForever = SKAction.repeatForever(SpawnDelay)
            self.run(spawnDelayForever)
            //3
            let distance = CGFloat(self.frame.width + wallPair.frame.width)
            let movePillars = SKAction.moveBy(x: -distance - 50, y: 0, duration: TimeInterval(0.008 * distance))
            let removePillars = SKAction.removeFromParent()
            moveAndRemove = SKAction.sequence([movePillars, removePillars])
            
            
            
            
            bird.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
            bird.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 40))
        } else {
            //4
            if isDied == false {
                bird.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
                bird.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 40))
            }
            
            
            //4- Once the game starts, the isGameStarted will be set to true, so for successive touches the else block is gonna be called and you just apply impulse on the bird as long as it’s not dead.
            
            
        }
        
        for touch in touches{
            let location = touch.location(in: self)
            //1
            if isDied == true{
                if restartBtn.contains(location){
                    if UserDefaults.standard.object(forKey: "highestScore") != nil {
                        let hscore = UserDefaults.standard.integer(forKey: "highestScore")
                        if hscore < Int(scoreLbl.text!)!{
                            UserDefaults.standard.set(scoreLbl.text, forKey: "highestScore")
                        }
                    } else {
                        UserDefaults.standard.set(0, forKey: "highestScore")
                    }
                    restartScene()
                }
            } else {
                //2
                if pauseBtn.contains(location){
                    if self.isPaused == false{
                        self.isPaused = true
                        pauseBtn.texture = SKTexture(imageNamed: "play")
                    } else {
                        self.isPaused = false
                        pauseBtn.texture = SKTexture(imageNamed: "pause")
                    }
                }
            }
        }
        
        
        
        
        
        
        
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if isGameStarted == true{
            if isDied == false{
            enumerateChildNodes(withName: "background", using: { (node, error) in
                let bg = node as! SKSpriteNode
                bg.position = CGPoint(x: bg.position.x - 2 , y: bg.position.y)
                
                if bg.position.x <= -bg.size.width{
                    bg.position = CGPoint(x: bg.position.x + bg.size.width * 2, y: bg.position.y)
                }
            })
            }}
    }
    
    
    //The method above will create a physics body around the entire screen using the edgeLoopFrom initializer. Then, you just used the CollisionBitMask struct constants you defined earlier, the categoryBitMask property is set to the groundCategory while the collisionBitMask and contactTestBitMask are set to the birdCategory constant because we want to detect collisions and contacts with the bird.
    
//important things to know about spritekit 
    
//  – categoryBitMask: A mask that defines which categories this physics body belongs to.
    
//  – collisionBitMask: A mask that defines which categories of physics can collide with this physics body.
    
//  – contactTestBitMask: A mask that defines which categories of bodies cause intersection notifications with this physics body.
    
//    
//  Category is simple enough: every node you want to reference in your collision bitmask or your contact test bitmask must have a category attached. If you give a node a collision bitmask but not a contact test bitmask, it means they will bounce off each other but you won’t be notified. If you do the opposite (contact test but not collision) it means they won’t bounce off each other but you will be told when they overlap.
    
//    
//  Collision prevents objects from intersecting. This is the default behavior when physics bodies are added.
    
//    
//  Contact is used when we need to know if two objects touch each other so we change the gameplay.
//    

    func createScene(){
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        
        self.physicsBody?.categoryBitMask = CollisionBitMask.groundCategory
        self.physicsBody?.collisionBitMask = CollisionBitMask.birdCategory
        self.physicsBody?.contactTestBitMask = CollisionBitMask.birdCategory
        self.physicsBody?.isDynamic = false
        
        //Setting the affectedByGravity to false will prevent the player from falling off the screen.
        
        self.physicsBody?.affectedByGravity = false
        
        //The purpose is that the Game object (the beetle) will collide with the walls around the screen, for this, setting the contactDelegate to self is mandatory for the GameScene class to implement the SKPhysicsContactDelegate protocol methods that help for detecting contacts and collisions.
        
        self.physicsWorld.contactDelegate = self
        self.backgroundColor = SKColor(red: 80.0/255.0, green: 192.0/255.0, blue: 203.0/255.0, alpha: 1.0)
        
        
        //set a background to the Scene
        
        for i in 0..<2{
            let background = SKSpriteNode(imageNamed: "bg")
            background.anchorPoint = CGPoint.init(x: 0, y: 0)
            background.position = CGPoint(x: CGFloat(i)*self.frame.width, y: 0)
            background.name = "background"
            background.size = (self.view?.bounds.size)!
            self.addChild(background)
        }
        
        //set up the birdsprites for animation
        //This will fill the birdSprites array with all the textures already prepared in player.atlas.
        

        birdSprites.append(birdAtlas.textureNamed("bird1"))
        birdSprites.append(birdAtlas.textureNamed("bird2"))
        birdSprites.append(birdAtlas.textureNamed("bird3"))
        birdSprites.append(birdAtlas.textureNamed("bird4"))
        
        
        
        self.bird = createBird()
        self.addChild(bird)
        
        //prepare to animate the bird and repeat the animation forever
        let animateBird = SKAction.animate(with: self.birdSprites as! [SKTexture], timePerFrame: 0.1)
        
        self.repeatActionBird = SKAction.repeatForever(animateBird)
        
        scoreLbl = createScoreLabel()
        self.addChild(scoreLbl)
        
        // we have to fixed the bug
//        highScoreLbl = createHighscoreLabel()
//        self.addChild(highScoreLbl)
        
        createLogo()
        
        taptoplayLbl = createTaptoplayLabel()
        self.addChild(taptoplayLbl)        
        
        
        
        
        
        
    }
    
    
    func restartScene(){
        self.removeAllChildren()
        self.removeAllActions()
        isDied = false
        isGameStarted = false
        score = 0
        createScene()
    }
    
    
    
    
}
